library(MASS)
set.seed(1)
fit = lm(nox ~ poly(dis, 3), data = Boston)
summary(fit)


dislims = range(Boston$dis)
dis.grid =seq(from = dislims[1], to = dislims[2], by = 0.1)
preds = predict(fit, list(dis = dis.grid))
plot(nox ~ dis, data = Boston, col = "darkgrey")
lines(dis.grid, preds, col = "red", lwd = 2)