libraray(ISLR)
attach(ISLR::Auto)
mpg01 = rep(0,length(mpg))
mpg01[mpg>median(mpg)]<-1
Auto<-data.frame(ISLR::Auto,mpg01)