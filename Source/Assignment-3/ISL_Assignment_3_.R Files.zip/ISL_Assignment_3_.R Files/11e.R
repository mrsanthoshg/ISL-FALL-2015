fit.qda = qda(mpg01~cylinders+weight+displacement+horsepower,data=Auto,subset=train)
fit.qda
pred.qda<-predict(fit.qda,Auto.test)
table(pred.qda$class,mpg01.test)
mean(pred.qda$class!=mpg01.test)

