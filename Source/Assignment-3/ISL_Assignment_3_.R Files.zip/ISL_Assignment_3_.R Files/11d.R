fit.lda = lda(mpg01~cylinders+weight+displacement+horsepower,data=Auto,subset=train)
fit.lda
pred.lda<-predict(fit.lda,Auto.test)
table(pred.lda$class,mpg01.test)
mean(pred.lda$class!=mpg01.test)

