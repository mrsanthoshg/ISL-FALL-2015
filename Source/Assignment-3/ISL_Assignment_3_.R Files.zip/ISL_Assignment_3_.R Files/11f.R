fit.glm = glm(mpg01~cylinders+weight+displacement+horsepower,data=Auto,subset=train)
summary(fit.glm)
probs = predict(fit.glm,Auto.test,type="response")
pred.glm = rep(0,length(probs))
pred.glm[probs>0.5]<-1
table(pred.glm,mpg01.test)
mean(pred.glm!=mpg01.test)
