##Using the Boston data set, fit classification models in order to predict
##whether a given suburb has a crime rate above or below the median.
##Explore logistic regression, LDA, and KNN models using various subsets
##of the predictors. Describe your findings.

##Exploring Logistic Regression1

library(MASS)
attach(MASS::Boston)
crim01 <- rep(0, length(crim))
crim01[crim > median(crim)] <- 1
Boston <- data.frame(MASS::Boston, crim01)
train <- 1:(length(crim)/2)
test <- (length(crim) / 2 + 1):length(crim)
Boston.train <- Boston[train, ]
Boston.test <- Boston[test, ]
crim01.test <- crim01[test]
fit.glm <- glm(crim01~. - crim01 - crim, data = Boston, family = binomial, subset=train)


probs <- predict(fit.glm, Boston.test, type = "response")
pred.glm <- rep(0, length(probs))
pred.glm[probs > 0.5] <- 1
table(pred.glm, crim01.test)

mean(pred.glm!=crim01.test)

##Exploring Logistic Regression2
fit.glm <- glm(crim01~. -crim01 - crim - chas - nox, data =Boston, family = binomial, subset=train)
probs <- predict(fit.glm, Boston.test, type = "response")
pred.glm <- rep(0, length(probs))
pred.glm[probs > 0.5] <- 1
table(pred.glm, crim01.test)

mean(pred.glm!=crim01.test)


##Exploring LDA1
fit.lda <- lda(crim01~. - crim01 - crim, data = Boston,subset = train)
pred.lda <- predict(fit.lda, Boston.test)
table(pred.lda$class, crim01.test)

mean(pred.lda$class !=crim01.test)


##Exploring LDA2

fit.lda <- lda(crim01~. - crim01 - crim - chas - nox, data = Boston, subset = train)
pred.lda <- predict(fit.lda, Boston.test)
table(pred.lda$class, crim01.test)

mean(pred.lda$class !=crim01.test)


##Exploring KNN
train.X=cbind(zn, indus, chas, nox, rm, age, dis, rad, tax, ptratio, black, lstat, medv)[train,]
train.X <- cbind(zn, indus, chas, nox, rm, age, dis, rad, tax, ptratio, black, lstat, medv)[train,]
test.X <- cbind(zn, indus, chas, nox, rm, age, dis, rad, tax, ptratio, black, lstat, medv)[test,]
train.crim01 <- crim01[train]
set.seed(1)
pred.knn <- knn(train.X, test.X, train.crim01, k=1)

mean(pred.knn !=crim01.test)


pred.knn <- knn(train.X, test.X, train.crim01, k=10)
table(pred.knn, crim01.test)
mean(pred.knn !=crim01.test)


pred.knn <- knn(train.X, test.X, train.crim01, k=100)
table(pred.knn, crim01.test)
mean(pred.knn !=crim01.test)


