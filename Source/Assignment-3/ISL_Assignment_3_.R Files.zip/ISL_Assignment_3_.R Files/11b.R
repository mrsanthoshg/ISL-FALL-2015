libraray(ISLR)
attach(ISLR::Auto)
mpg01 = rep(0,length(mpg))
mpg01[mpg>median(mpg)]<-1
Auto<-data.frame(ISLR::Auto,mpg01)
cor(Auto[, -9])
pairs(Auto)
boxplot(cylinders~mpg01,data=Auto,main="Cylinders vs mpg01")
boxplot(displacement~mpg01,data=Auto,main="Displacement vs mpg01")
boxplot(horsepower~mpg01,data=Auto,main="Horsepower vs mpg01")
boxplot(weight~mpg01,data=Auto,main="Weight vs mpg01")
boxplot(acceleration~mpg01,data=Auto,main="Acceleration vs mpg01")
boxplot(year~mpg01,data=Auto,main="Year vs mpg01")


