train.X = cbind(cylinders,weight,displacement,horsepower)[train,]
train.X <- cbind(cylinders,weight,displacement,horsepower)[train,]
test.X <- cbind(cylinders,weight,displacement,horsepower)[!train,]
train.mpg01<-mpg01[train]
set.seed(1)
pred.knn<-knn(train.X,test.X,train.mpg01,k=1)
table(pred.knn,mpg01.test)
mean(pred.knn!=mpg01.test)
pred.knn<-knn(train.X,test.X,train.mpg01,k=10)
table(pred.knn,mpg01.test)
mean(pred.knn!=mpg01.test)
pred.knn<-knn(train.X,test.X,train.mpg01,k=100)
table(pred.knn,mpg01.test)
mean(pred.knn!=mpg01.test)