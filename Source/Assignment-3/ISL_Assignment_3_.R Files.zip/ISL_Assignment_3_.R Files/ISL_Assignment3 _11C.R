train<-(year %% 2 ==0)
Auto.train<-Auto[train,]
Auto.test<-Auto[!train,]
mpg01.test<-mpg01[!train]
