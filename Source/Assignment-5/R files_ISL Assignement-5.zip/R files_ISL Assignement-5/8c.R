set.seed(1)
X=rnorm(100,mean=0,sd=1)
e=rnorm(100,mean=0,sd=0.5)
B0=150.3
B1=50.5
B2=-10.1
B3=-34.2

Y=B0+ B1*X + B2*(X^2) + B3*(X^3) + e

dat=data.frame(Y=Y,X=X)
library(leaps)
library(ISLR)

regfit.full=regsubsets(Y~poly(X,10,raw=T),data=dat,nvmax=10)
reg.summary=summary(regfit.full)
par(mfrow=c(2,2))
plot(reg.summary$rss,xlab="Number of Variables",ylab="RSS",type="l")
plot(reg.summary$adjr2,xlab="Number of Variables",ylab="Adjusted RSq",type="l")
points(which.max(reg.summary$adjr2),
       reg.summary$adjr2[which.max(reg.summary$adjr2)],
       col="red",cex=2,pch=20)
plot(reg.summary$cp,xlab="Number of Variables",ylab="Cp",
     type="l")
points(which.min(reg.summary$cp),
       reg.summary$cp[which.min(reg.summary$cp)],
       col="red",cex=2,pch=20)
plot(reg.summary$bic,xlab="Number of Variables",
     ylab="BIC", type="l")
points(which.min(reg.summary$bic),
       reg.summary$bic[which.min(reg.summary$bic)],
       col="red",cex=2,pch=20)

# BIC
coef(regfit.full,3)
# Cp/adjusted R2
coef(regfit.full,4)