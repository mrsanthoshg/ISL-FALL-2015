set.seed(1)
train=sample(c(TRUE,FALSE),nrow(College),rep=TRUE)
test=(!train)

College.train=College[train,,drop=F]
College.test=College[test,,drop=F]