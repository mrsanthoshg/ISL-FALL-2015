#8.a) Use the rnorm function to generate a predictor X of length n = 100, as wells as noise vector  of length n = 100

#Solution:

set.seed(1)
X=rnorm(100,mean=0,sd=1)
e=rnorm(100,mean=0,sd=0.5)