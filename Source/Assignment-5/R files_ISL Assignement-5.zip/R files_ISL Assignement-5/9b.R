lm.fit=lm(Apps~.,data=College.train)
summary(lm.fit)
pred=predict(lm.fit,College.test)
rss=sum((pred-College.test$Apps)^2)
tss=sum((College.test$Apps-mean(College.test$Apps))^2)
test.rsq=1-(rss/tss)
test.rsq