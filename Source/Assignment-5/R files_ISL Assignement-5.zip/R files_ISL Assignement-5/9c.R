### Scale the training data, and scale the test data using the centers/scale
# learned on the training data. 
library(glmnet)
College.train.X=scale(model.matrix(Apps~.,data=College.train)[,-1],scale=T,center=T)
College.train.Y=College.train$Apps

College.test.X=scale(model.matrix(Apps~.,data=College.test)[,-1],
                     attr(College.train.X,"scaled:center"),
                     attr(College.train.X,"scaled:scale"))

College.test.Y=College.test$Apps

cv.out=cv.glmnet(College.train.X,College.train.Y,alpha=0)
bestlam=cv.out$lambda.min
bestlam

lasso.mod=glmnet(College.train.X,College.train.Y,alpha=0,lambda=bestlam)
pred=predict(lasso.mod,College.test.X,s=bestlam)
rss=sum((pred-College.test$Apps)^2)
tss=sum((College.test$Apps-mean(College.test$Apps))^2)
test.rsq=1-(rss/tss)
test.rsq