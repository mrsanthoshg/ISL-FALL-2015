#8. (b)Generate a response vector Y of length n = 100 according to the model
#Y = ??0 + ??1X + ??2X2 + ??3X3 + , where ??0, ??1, ??2, and ??3 are constants of your choice.library(leaps)             

#Soltuion:
  
B0=150.3
B1=50.5
B2=-10.1
B3=-34.2

Y=B0+ B1*X + B2*(X^2) + B3*(X^3) + e