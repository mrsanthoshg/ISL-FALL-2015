library(boot)
boot(Default, boot.fn, 1000)