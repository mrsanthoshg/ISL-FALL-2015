library(boot)
Data = data.frame(x, y)
set.seed(10)
glmfitting = glm(y ~ x)
cv.glm(Data, glmfitting)$delta