library(boot)
Data = data.frame(x, y)
set.seed(1)
glmfitting = glm(y ~ poly(x, 2))
cv.glm(Data, glmfitting)$delta