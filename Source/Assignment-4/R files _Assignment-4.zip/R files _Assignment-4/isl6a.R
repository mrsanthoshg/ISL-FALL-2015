
set.seed(1)
glm.fit=glm(default~income+balance,data=Default, family="binomial")
summary(glm.fit)

