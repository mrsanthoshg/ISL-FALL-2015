boot.fn = function(data, index) {
  model = glm(default ~ income + balance, data = data, family = "binomial", subset = index)
  return (coef(model))
}