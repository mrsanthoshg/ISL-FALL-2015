library(boot)
Data = data.frame(x, y)
set.seed(1)
glmfitting = glm(y ~ x)
cv.glm(Data, glmfitting)$delta